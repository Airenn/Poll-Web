<?php
    require_once('../php/connexion.php');
    require_once('../php/fonctions.php');

    create_dropdown($_GET['operation']);
?>