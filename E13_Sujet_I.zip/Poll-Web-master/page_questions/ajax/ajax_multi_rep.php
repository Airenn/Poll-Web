<?php
    require_once('../php/connexion.php');
    require_once('../php/fonctions.php');
    
    multi_rep_quest($_GET['question']);
?>