<?php
    require_once('../php/connexion.php');
    require_once('../php/fonctions.php');

    change_numero($_GET['question'], $_GET['num_question']);
?>