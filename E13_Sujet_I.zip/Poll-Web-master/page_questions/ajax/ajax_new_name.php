<?php
    require_once('../php/connexion.php');
    require_once('../php/fonctions.php');

    change_name($_GET['question'], $_GET['texte']);
?>