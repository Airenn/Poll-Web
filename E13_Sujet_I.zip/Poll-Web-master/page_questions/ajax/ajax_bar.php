<?php
    require_once('../php/connexion.php');
    require_once('../php/fonctions.php');

    create_progress_bars($_GET['question'], $_GET['categorie']); 
?>