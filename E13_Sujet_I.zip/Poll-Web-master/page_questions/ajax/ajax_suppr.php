<?php
    require_once('../php/connexion.php');
    require_once('../php/fonctions.php');
    
    delete_messages_quest($_GET['question']);
?>