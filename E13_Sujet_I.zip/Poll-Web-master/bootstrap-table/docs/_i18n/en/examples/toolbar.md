# Toolbar []({{ site.repo }}/blob/master/docs/_i18n/{{ site.lang }}/examples/toolbar.md)

---

## Basic Toolbar

Use `search`, `showColumns`, `showRefresh`, `showToggle` options to show the basic toolbars. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" src="http://jsfiddle.net/wenyi/e3nk137y/33/embedded/html,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## Custom Toolbar

Use `toolbar` option to define the custom toolbars. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" src="http://jsfiddle.net/wenyi/e3nk137y/34/embedded/html,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>