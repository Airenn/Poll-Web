# Methods []({{ site.repo }}/blob/master/docs/_i18n/{{ site.lang }}/examples/methods.md)

---

## Reset View

The table header does not adjust automatically, We need to call `resetView` method. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" src="http://jsfiddle.net/wenyi/e3nk137y/40/embedded/html,js,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>


<!--
## Data Methods


## Merge Cells


## Check Methods


## Column Methods
-->