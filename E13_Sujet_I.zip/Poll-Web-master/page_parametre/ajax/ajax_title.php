<?php 
    require("../../page_questions/php/connexion.php");
    require("../../page_questions/php/fonctions.php");
    require("../php/fonctions.php");
    create_title(); 
?>
